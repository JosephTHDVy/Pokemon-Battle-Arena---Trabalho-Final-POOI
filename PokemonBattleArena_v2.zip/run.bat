@echo off
REM Pokémon Battle Arena — compilação e execução (Windows)
echo === Compilando Pokemon Battle Arena ===
if not exist out mkdir out
for /R src %%f in (*.java) do set SOURCES=!SOURCES! "%%f"
setlocal enabledelayedexpansion
set SOURCES=
for /R src %%f in (*.java) do set SOURCES=!SOURCES! "%%f"
javac -d out %SOURCES%
if errorlevel 1 (
    echo ERRO: falha na compilacao.
    pause
    exit /b 1
)
echo Compilacao OK. Iniciando jogo...
echo.
java -cp out br.unicentro.pokemon.Main
pause
