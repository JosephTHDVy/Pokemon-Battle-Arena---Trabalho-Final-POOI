============================================================
  POKÉMON BATTLE ARENA — Java Edition
  Trabalho de POO I — UNICENTRO 2026
  Autor: Guizo
============================================================

DESCRIÇÃO DO JOGO
-----------------
Jogo de batalha Pokémon por turnos com interface textual (ANSI).
Existem 3 times pré-definidos (Vermelho, Azul, Verde), cada um
com 3 Pokémon. O jogador escolhe um time e um Pokémon inicial,
então enfrenta 1v1 cada Pokémon dos outros dois times inimigos.
Entre batalhas, pode trocar livremente de Pokémon.
Os resultados são salvos no ranking (recursos/ranking.csv).

COMO EXECUTAR
-------------
Pré-requisito: Java 17 ou superior.

1. Compile todos os .java:
   Windows (PowerShell):
     javac -d out (Get-ChildItem -Recurse src/*.java | Select -ExpandProperty FullName)

   Linux/macOS:
     find src -name "*.java" | xargs javac -d out

2. Execute a partir da raiz do projeto:
     java -cp out br.unicentro.pokemon.Main

   OU use o script:
     Windows: run.bat
     Linux:   ./run.sh

CONCEITOS DE POO APLICADOS
---------------------------
• Encapsulamento    — atributos private em todas as classes; acesso via getters/setters
• Herança           — Pokemon (abstrata) → Charizard, Blastoise, Venusaur, etc.
                    — Ataque (abstrata) → AtaqueFisico, AtaqueEspecial
• Interface         — Combatente (atacar, estaConsciente, getNome)
• Classe abstrata   — Pokemon e Ataque com métodos abstratos
• Polimorfismo      — lista de Pokemon tratada via referência abstrata/interface
• Agregação         — Time agrega Pokémon (existem independentemente)
• Composição        — Jogo compõe GerenciadorRanking e FabricaTime
• Exceções          — PokemonSemForcaException, AtaqueInvalidoException (personalizadas)
• Estruturas        — ArrayList (times, membros, ataques), List imutável, Collections.sort
• Arquivos          — GerenciadorRanking lê/grava recursos/ranking.csv via java.nio.file
• Javadoc           — Todas as classes documentadas com @author @version @param @return @exception
• Enum              — TipoPokemon com lógica de multiplicador de efetividade
• Packages          — br.unicentro.pokemon.{modelo, batalha, dados, ui, util, excecao}

FUNCIONALIDADE EXTRA — RANKING
-------------------------------
Ao final de cada sessão de jogo, o resultado (vitória/derrota,
Pokémon usado, número de vitórias acumuladas) é salvo no arquivo
recursos/ranking.csv. O ranking é exibível a qualquer momento
pelo menu principal, mostrando todos os jogadores ordenados por
número de vitórias.

Arquivo: recursos/ranking.csv
Formato: nome;vitorias;derrotas;pokemon_favorito

ESTRUTURA DO PROJETO
--------------------
src/
 └── br/unicentro/pokemon/
      ├── Main.java
      ├── Jogo.java
      ├── modelo/
      │    ├── Pokemon.java          (abstrata)
      │    ├── Time.java
      │    ├── TipoPokemon.java      (enum)
      │    ├── Combatente.java       (interface)
      │    ├── EntradaBatalha.java
      │    ├── ataque/
      │    │    ├── Ataque.java      (abstrata)
      │    │    ├── AtaqueFisico.java
      │    │    └── AtaqueEspecial.java
      │    └── pokemon/
      │         └── TodosPokemon.java (9 subclasses)
      ├── batalha/
      │    └── Batalha.java
      ├── dados/
      │    ├── FabricaTime.java
      │    └── GerenciadorRanking.java
      ├── ui/
      │    └── Tela.java
      ├── util/
      │    └── Entrada.java
      └── excecao/
           ├── PokemonSemForcaException.java
           └── AtaqueInvalidoException.java
recursos/
 └── ranking.csv  (gerado automaticamente)
============================================================
