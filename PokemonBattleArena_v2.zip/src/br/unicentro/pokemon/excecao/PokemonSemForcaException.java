package br.unicentro.pokemon.excecao;

/**
 * Lançada quando se tenta usar um Pokémon que está sem HP (desmaiado).
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public class PokemonSemForcaException extends Exception {

    private final String nomePokemon;

    /**
     * Cria a exceção com o nome do Pokémon afetado.
     *
     * @param nomePokemon nome do Pokémon que desmaiou
     */
    public PokemonSemForcaException(String nomePokemon) {
        super(nomePokemon + " não pode batalhar — está sem forças!");
        this.nomePokemon = nomePokemon;
    }

    /**
     * Retorna o nome do Pokémon que causou a exceção.
     *
     * @return nome do Pokémon
     */
    public String getNomePokemon() {
        return nomePokemon;
    }
}
