package br.unicentro.pokemon.excecao;

/**
 * Lançada quando se tenta usar um ataque em um slot inválido
 * ou quando o Pokémon não possui aquele ataque.
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public class AtaqueInvalidoException extends Exception {

    private final int slotInformado;

    /**
     * Cria a exceção com o slot inválido informado.
     *
     * @param slot slot de ataque informado pelo jogador
     */
    public AtaqueInvalidoException(int slot) {
        super("Slot de ataque inválido: " + slot + ". Escolha entre os ataques disponíveis.");
        this.slotInformado = slot;
    }

    /**
     * Retorna o slot inválido que causou a exceção.
     *
     * @return número do slot informado
     */
    public int getSlotInformado() {
        return slotInformado;
    }
}
