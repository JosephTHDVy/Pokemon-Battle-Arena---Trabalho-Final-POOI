package br.unicentro.pokemon.util;

import java.util.Scanner;

/**
 * Centraliza a leitura do console, evitando múltiplos Scanners no projeto.
 * Padrão Singleton de acesso ao Scanner da aplicação.
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public final class Entrada {

    private static final Scanner SC = new Scanner(System.in);

    private Entrada() {}

    /**
     * Lê uma linha inteira do console.
     *
     * @return texto digitado pelo usuário (sem newline)
     */
    public static String lerLinha() { return SC.nextLine().trim(); }

    /**
     * Lê um inteiro do console; retorna {@code -1} se a entrada não for numérica.
     *
     * @return inteiro lido ou -1 em caso de entrada inválida
     */
    public static int lerInt() {
        String s = SC.nextLine().trim();
        try { return Integer.parseInt(s); }
        catch (NumberFormatException e) { return -1; }
    }

    /**
     * Aguarda o usuário pressionar Enter para continuar.
     */
    public static void aguardarEnter() {
        System.out.print("  [ Pressione ENTER para continuar ] ");
        SC.nextLine();
    }

    /**
     * Fecha o Scanner. Deve ser chamado ao encerrar a aplicação.
     */
    public static void fechar() { SC.close(); }
}
