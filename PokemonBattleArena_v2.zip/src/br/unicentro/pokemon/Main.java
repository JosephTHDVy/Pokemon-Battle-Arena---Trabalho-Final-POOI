package br.unicentro.pokemon;

/**
 * Ponto de entrada da aplicação Pokémon Battle Arena.
 * Instancia e inicia o controlador principal {@link Jogo}.
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public class Main {

    /**
     * Método principal da aplicação.
     *
     * @param args argumentos de linha de comando (não utilizados)
     */
    public static void main(String[] args) {
        new Jogo().iniciar();
    }
}
