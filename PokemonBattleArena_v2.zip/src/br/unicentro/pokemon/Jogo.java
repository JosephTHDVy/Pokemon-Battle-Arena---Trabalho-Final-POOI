package br.unicentro.pokemon;

import br.unicentro.pokemon.batalha.Batalha;
import br.unicentro.pokemon.dados.FabricaTime;
import br.unicentro.pokemon.dados.GerenciadorRanking;
import br.unicentro.pokemon.excecao.AtaqueInvalidoException;
import br.unicentro.pokemon.excecao.PokemonSemForcaException;
import br.unicentro.pokemon.modelo.Pokemon;
import br.unicentro.pokemon.modelo.Time;
import br.unicentro.pokemon.ui.Tela;
import br.unicentro.pokemon.util.Entrada;

import java.util.ArrayList;
import java.util.List;

/**
 * Controlador central do jogo Pokémon Battle Arena.
 * Gerencia o fluxo: menu principal → seleção de time → batalhas → ranking.
 * A lógica de jogo é independente da UI (classe {@link Tela}).
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public class Jogo {

    private final List<Time>       times;
    private final GerenciadorRanking ranking;
    private String                 nomeJogador;
    private Time                   timeJogador;
    private Pokemon                pokemonAtual;

    /**
     * Inicializa o jogo criando os três times e carregando o ranking.
     */
    public Jogo() {
        times   = new ArrayList<>();
        times.add(FabricaTime.criarTimeVermelho());
        times.add(FabricaTime.criarTimeAzul());
        times.add(FabricaTime.criarTimeVerde());
        ranking = new GerenciadorRanking();
    }

    /**
     * Inicia o loop principal do jogo.
     */
    public void iniciar() {
        Tela.titulo();
        System.out.print("  Digite seu nome de treinador: ");
        nomeJogador = Entrada.lerLinha();
        if (nomeJogador.isBlank()) nomeJogador = "Treinador";

        boolean rodando = true;
        while (rodando) {
            rodando = menuPrincipal();
        }
        Tela.log("\n  Até a próxima, " + nomeJogador + "! ✦");
        Entrada.fechar();
    }

    // ─── Menu principal ────────────────────────────────────────────────────────

    private boolean menuPrincipal() {
        Tela.limpar();
        Tela.separador();
        System.out.println(Tela.NEGRITO + "  MENU PRINCIPAL — " + nomeJogador + Tela.RESET);
        Tela.separador();
        System.out.println("  [1] Jogar — Escolher time e batalhar");
        System.out.println("  [2] Ver Ranking");
        System.out.println("  [3] Como jogar");
        System.out.println("  [0] Sair");
        Tela.separador();
        System.out.print("  Escolha: ");

        return switch (Entrada.lerInt()) {
            case 1  -> { fluxoJogo(); yield true; }
            case 2  -> { Tela.exibirRanking(ranking.getRankingOrdenado()); Entrada.aguardarEnter(); yield true; }
            case 3  -> { exibirAjuda(); yield true; }
            case 0  -> false;
            default -> { Tela.log("  Opção inválida."); yield true; }
        };
    }

    // ─── Fluxo de jogo ─────────────────────────────────────────────────────────

    private void fluxoJogo() {
        // 1. Selecionar time
        selecionarTime();

        // 2. Selecionar Pokémon inicial
        selecionarPokemonInicial();

        // 3. Batalhar contra os dois times inimigos
        List<Time> inimigos = new ArrayList<>(times);
        inimigos.remove(timeJogador);

        int vitorias = 0;
        for (Time timeInimigo : inimigos) {
            timeInimigo.restaurarTime();
            boolean venceu = conduzirBatalhasContraTime(timeInimigo);
            if (venceu) {
                vitorias++;
                Tela.log(Tela.VERDE + Tela.NEGRITO +
                        "\n  ✦ Você derrotou " + timeInimigo.getNome() + "!" + Tela.RESET);
            } else {
                Tela.log(Tela.VERM + Tela.NEGRITO +
                        "\n  ✦ Você foi derrotado por " + timeInimigo.getNome() + "." + Tela.RESET);
                break;
            }
            Entrada.aguardarEnter();
            // Restaura HP entre times — jogador escolhe com qual Pokémon continua
            timeJogador.restaurarTime();
            Tela.log(Tela.CIANO + "\n  Seus Pokémon foram recuperados! Escolha com qual continuar:" + Tela.RESET);
            selecionarPokemonInicial();
        }

        // 4. Resultado final
        boolean venceuTudo = vitorias == inimigos.size();
        ranking.registrar(nomeJogador, venceuTudo, pokemonAtual.getNome());
        exibirResultadoFinal(venceuTudo);
        Entrada.aguardarEnter();
    }

    // ─── Seleção de time ───────────────────────────────────────────────────────

    private void selecionarTime() {
        Tela.limpar();
        Tela.exibirTimes(times);
        System.out.print("  Escolha seu time [1-3]: ");
        int escolha;
        do {
            escolha = Entrada.lerInt();
        } while (escolha < 1 || escolha > 3);
        timeJogador = times.get(escolha - 1);
        timeJogador.restaurarTime();
        Tela.log("\n  " + Tela.VERDE + "Time " + timeJogador.getNome() + " selecionado!" + Tela.RESET);
    }

    private void selecionarPokemonInicial() {
        Tela.exibirSelecaoPokemon(timeJogador);
        System.out.print("  Escolha [1-3]: ");
        int idx;
        do { idx = Entrada.lerInt() - 1; }
        while (idx < 0 || idx >= timeJogador.getMembros().size());
        pokemonAtual = timeJogador.getMembros().get(idx);
        Tela.log("  " + Tela.AMAREL + "Vai " + pokemonAtual.getNome() + "!" + Tela.RESET);
        Entrada.aguardarEnter();
    }

    // ─── Batalhas ──────────────────────────────────────────────────────────────

    /**
     * Conduz batalhas 1v1 contra cada Pokémon de um time inimigo.
     *
     * @param timeInimigo time adversário
     * @return {@code true} se o jogador venceu todos os três
     */
    private boolean conduzirBatalhasContraTime(Time timeInimigo) {
        for (Pokemon inimigo : timeInimigo.getMembros()) {
            boolean venceu = conduzirBatalha1v1(inimigo);
            if (!venceu) return false;
            Tela.log("\n  " + Tela.VERDE + inimigo.getNome() + " desmaiou!" + Tela.RESET);
            Entrada.aguardarEnter();
            // Oferecer troca entre batalhas
            if (timeJogador.getMembros().stream()
                    .filter(p -> p != pokemonAtual)
                    .anyMatch(Pokemon::estaConsciente)) {
                System.out.print("  Deseja trocar de Pokémon antes da próxima batalha? [s/n]: ");
                if (Entrada.lerLinha().equalsIgnoreCase("s")) {
                    trocaPokemon(true);
                }
            }
        }
        return true;
    }

    /**
     * Loop de um combate 1v1 completo.
     *
     * @param inimigo Pokémon inimigo nesta rodada
     * @return {@code true} se o jogador venceu
     */
    private boolean conduzirBatalha1v1(Pokemon inimigo) {
        Batalha batalha = new Batalha(pokemonAtual, inimigo);

        while (pokemonAtual.estaConsciente() && inimigo.estaConsciente()) {
            Tela.desenharArena(pokemonAtual, inimigo, batalha.getTurno());
            Tela.exibirMenuAtaque(pokemonAtual);

            int opcao = Entrada.lerInt();

            if (opcao == 9) {
                // Fugir encerra o jogo do jogador
                Tela.log("  Você fugiu da batalha...");
                return false;
            }

            if (opcao == 0) {
                trocaPokemon(true);
                if (!pokemonAtual.estaConsciente()) return false;
                batalha = new Batalha(pokemonAtual, inimigo);
                continue;
            }

            // Ataque do jogador
            boolean inimigoVencido = false;
            if (batalha.jogadorEhMaisRapido()) {
                inimigoVencido = processarAtaqueJogador(batalha, opcao - 1);
                if (!inimigoVencido && inimigo.estaConsciente()) {
                    processarAtaqueInimigo(batalha);
                }
            } else {
                processarAtaqueInimigo(batalha);
                if (pokemonAtual.estaConsciente()) {
                    inimigoVencido = processarAtaqueJogador(batalha, opcao - 1);
                }
            }

            // Pokémon do jogador desmaiou → tentar troca
            if (!pokemonAtual.estaConsciente()) {
                Tela.derrota(pokemonAtual.getNome());
                Entrada.aguardarEnter();
                if (timeJogador.temPokemonVivo()) {
                    trocaPokemon(true);
                    if (pokemonAtual.estaConsciente()) {
                        batalha = new Batalha(pokemonAtual, inimigo);
                        continue;
                    }
                }
                return false;
            }

            Entrada.aguardarEnter();
        }
        return !inimigo.estaConsciente();
    }

    private boolean processarAtaqueJogador(Batalha batalha, int idx) {
        try {
            return batalha.turnoJogador(idx);
        } catch (AtaqueInvalidoException e) {
            Tela.log("  " + Tela.VERM + e.getMessage() + Tela.RESET);
        } catch (PokemonSemForcaException e) {
            Tela.log("  " + Tela.VERM + e.getMessage() + Tela.RESET);
        }
        return false;
    }

    private void processarAtaqueInimigo(Batalha batalha) {
        batalha.turnoInimigo();
    }

    // ─── Troca de Pokémon ──────────────────────────────────────────────────────

    private void trocaPokemon(boolean mostrarTela) {
        List<Pokemon> vivos = timeJogador.getMembros().stream()
                .filter(p -> p.estaConsciente() && p != pokemonAtual)
                .toList();
        if (vivos.isEmpty()) {
            Tela.log("  Nenhum Pokémon disponível para troca!");
            return;
        }
        if (mostrarTela) Tela.exibirTrocaPokemon(timeJogador);
        int idx = -1;
        while (true) {
            int input = Entrada.lerInt() - 1;
            if (input < 0 || input >= timeJogador.getMembros().size()) {
                Tela.log("  Opção inválida. Tente novamente: ");
                continue;
            }
            Pokemon escolhido = timeJogador.getMembros().get(input);
            if (!escolhido.estaConsciente()) {
                Tela.log("  " + escolhido.getNome() + " está desmaiado! Escolha outro: ");
                continue;
            }
            idx = input;
            break;
        }
        pokemonAtual = timeJogador.getMembros().get(idx);
        Tela.log("  " + Tela.AMAREL + "Vai " + pokemonAtual.getNome() + "!" + Tela.RESET);
    }

    // ─── Resultado final ───────────────────────────────────────────────────────

    private void exibirResultadoFinal(boolean venceu) {
        Tela.limpar();
        Tela.separador();
        if (venceu) {
            System.out.println(Tela.AMAREL + Tela.NEGRITO +
                    "  🏆  CAMPEÃO!  " + nomeJogador +
                    " conquistou a Battle Arena!" + Tela.RESET);
        } else {
            System.out.println(Tela.VERM + Tela.NEGRITO +
                    "  Você foi derrotado. Tente novamente!" + Tela.RESET);
        }
        System.out.println("  Resultado registrado no ranking ✓");
        Tela.separador();
        Tela.exibirRanking(ranking.getRankingOrdenado());
    }

    // ─── Ajuda ─────────────────────────────────────────────────────────────────

    private void exibirAjuda() {
        Tela.limpar();
        Tela.separador();
        System.out.println(Tela.NEGRITO + "  COMO JOGAR" + Tela.RESET);
        Tela.separador();
        System.out.println("  1. Escolha um dos três times (Vermelho, Azul, Verde).");
        System.out.println("  2. Selecione o Pokémon inicial do seu time.");
        System.out.println("  3. Batalhe 1v1 contra cada Pokémon dos outros dois times.");
        System.out.println("  4. Em cada turno escolha um ataque [1-4].");
        System.out.println("  5. [0] troca o Pokémon em campo. [9] foge da batalha.");
        System.out.println("  6. Você pode trocar livremente entre batalhas.");
        System.out.println("  7. Derrote todos os 6 Pokémon inimigos para vencer!");
        System.out.println();
        System.out.println("  EFETIVIDADE DE TIPOS:");
        System.out.println("   Fogo > Planta > Água > Fogo");
        System.out.println("   Elétrico > Água   Lutador > Pedra/Normal");
        System.out.println("   Psíquico > Lutador");
        System.out.println();
        System.out.println("  HABILIDADES PASSIVAS:");
        System.out.println("   Cada Pokémon tem uma habilidade única ativa automaticamente.");
        Tela.separador();
        Entrada.aguardarEnter();
    }
}
