package br.unicentro.pokemon.batalha;

import br.unicentro.pokemon.excecao.AtaqueInvalidoException;
import br.unicentro.pokemon.excecao.PokemonSemForcaException;
import br.unicentro.pokemon.modelo.Pokemon;
import br.unicentro.pokemon.modelo.pokemon.TodosPokemon.*;
import br.unicentro.pokemon.ui.Tela;

/**
 * Gerencia a lógica de um turno de batalha 1v1 entre dois Pokémon.
 * Aplica habilidades passivas, calcula ordem por velocidade e processa ataques.
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public class Batalha {

    private final Pokemon jogador;
    private final Pokemon inimigo;
    private int turno;
    private boolean paralisiado;

    /**
     * Cria uma batalha entre dois Pokémon.
     *
     * @param jogador Pokémon controlado pelo jogador
     * @param inimigo Pokémon controlado pela IA
     */
    public Batalha(Pokemon jogador, Pokemon inimigo) {
        this.jogador   = jogador;
        this.inimigo   = inimigo;
        this.turno     = 1;
        this.paralisiado = false;

        // Intimidate de Gyarados ao entrar em campo
        if (inimigo instanceof Gyarados g && g.aplicarIntimidate()) {
            Tela.log("  ⚡ " + inimigo.getNome() + " usa Intimidate! ATK do jogador reduzido.");
        }
    }

    /**
     * Executa o turno do jogador: aplica passiva, processa ataque escolhido.
     *
     * @param indiceAtaque índice 0-based do ataque escolhido
     * @return {@code true} se o inimigo foi derrotado neste turno
     * @exception AtaqueInvalidoException  se o índice for inválido
     * @exception PokemonSemForcaException se o jogador estiver desmaiado
     */
    public boolean turnoJogador(int indiceAtaque)
            throws AtaqueInvalidoException, PokemonSemForcaException {

        // Passiva do jogador no início do turno
        jogador.aplicarHabilidadePassiva();
        if (jogador instanceof Venusaur || jogador instanceof Alakazam) {
            Tela.log("  🌿 Habilidade passiva de " + jogador.getNome() + " restaurou HP!");
        }

        // Paralisia de Static
        if (paralisiado && Math.random() < 0.25) {
            Tela.log("  ⚡ " + jogador.getNome() + " está paralisado e não pode atacar!");
            return false;
        }

        int dano = jogador.atacar(indiceAtaque, inimigo);
        String atqNome = jogador.getAtaques().get(indiceAtaque).getNome();

        // Gengar Levitate
        if (inimigo instanceof Gengar gengar &&
                gengar.levitateAtivo(jogador.getAtaques().get(indiceAtaque).getTipo())) {
            Tela.log("  🌀 Levitate! " + inimigo.getNome() + " é imune — dano anulado!");
            inimigo.curar(dano); // desfaz o dano
            return false;
        }

        double mult = jogador.getAtaques().get(indiceAtaque).getTipo()
                             .multiplicador(inimigo.getTipo());
        String efeit = efetividadeTexto(mult);

        // Blaze
        if (jogador instanceof Charizard ch && ch.blazeAtivo()) {
            Tela.log("  🔥 Blaze ativado! Dano amplificado!");
        }

        Tela.log(String.format("  ➤ %s usa %s! Causou %d de dano. %s",
                jogador.getNome(), atqNome, dano, efeit));

        // Rock Head — Golem devolve dano
        if (inimigo instanceof Golem) {
            int reflexo = (int)(dano * 0.10);
            jogador.receberDano(reflexo);
            Tela.log("  🪨 Rock Head! " + inimigo.getNome() +
                    " devolveu " + reflexo + " de dano a " + jogador.getNome() + "!");
        }

        return !inimigo.estaConsciente();
    }

    /**
     * Executa o turno da IA: escolhe ataque aleatório e ataca o jogador.
     *
     * @return {@code true} se o jogador foi derrotado neste turno
     */
    public boolean turnoInimigo() {
        // Passiva do inimigo
        inimigo.aplicarHabilidadePassiva();

        int qtdAtaques = inimigo.getAtaques().size();
        int escolha    = (int)(Math.random() * qtdAtaques);
        String atqNome = inimigo.getAtaques().get(escolha).getNome();

        try {
            int dano = inimigo.atacar(escolha, jogador);
            double mult = inimigo.getAtaques().get(escolha).getTipo()
                                 .multiplicador(jogador.getTipo());
            String efeit = efetividadeTexto(mult);

            // Static do Pikachu ao levar ataque
            if (jogador instanceof Pikachu pk && pk.verificarStatic()) {
                paralisiado = true;
                Tela.log("  ⚡ Static! " + inimigo.getNome() + " foi paralisado!");
            }

            Tela.log(String.format("  ➤ %s usa %s! Causou %d de dano. %s",
                    inimigo.getNome(), atqNome, dano, efeit));

        } catch (AtaqueInvalidoException | PokemonSemForcaException e) {
            Tela.log("  [IA] Erro de ataque: " + e.getMessage());
        }

        turno++;
        return !jogador.estaConsciente();
    }

    /**
     * Verifica se o jogador age primeiro (maior velocidade).
     *
     * @return {@code true} se o jogador for mais rápido
     */
    public boolean jogadorEhMaisRapido() {
        return jogador.getVelocidade() >= inimigo.getVelocidade();
    }

    /** @return número do turno atual */
    public int getTurno() { return turno; }

    private String efetividadeTexto(double mult) {
        if (mult >= 2.0) return "[ É super eficaz! ]";
        if (mult <= 0.5) return "[ Não é muito eficaz... ]";
        return "";
    }
}
