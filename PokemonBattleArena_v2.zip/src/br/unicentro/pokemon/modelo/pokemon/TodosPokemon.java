package br.unicentro.pokemon.modelo.pokemon;

import br.unicentro.pokemon.modelo.Pokemon;
import br.unicentro.pokemon.modelo.TipoPokemon;
import br.unicentro.pokemon.modelo.ataque.AtaqueFisico;
import br.unicentro.pokemon.modelo.ataque.AtaqueEspecial;

/**
 * Contém todas as nove subclasses concretas de Pokémon do jogo.
 * Cada uma possui habilidade passiva única e conjunto de ataques pré-definidos.
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public final class TodosPokemon {

    private TodosPokemon() {}

    // ════════════════════════════════════════════════════════════
    //  TIME VERMELHO — Charizard, Blastoise, Venusaur
    // ════════════════════════════════════════════════════════════

    /**
     * Charizard — Tipo Fogo. Habilidade: Blaze (boost de ataque com HP baixo).
     */
    public static class Charizard extends Pokemon {
        public Charizard() {
            super("Charizard", TipoPokemon.FOGO, 266, 104, 78, 100);
            adicionarAtaque(new AtaqueEspecial("Lança-Chamas",  TipoPokemon.FOGO,    90, 15));
            adicionarAtaque(new AtaqueEspecial("Fogo Sagrado",  TipoPokemon.FOGO,   110,  5));
            adicionarAtaque(new AtaqueFisico  ("Garra Dragão",  TipoPokemon.NORMAL,  80, 15));
            adicionarAtaque(new AtaqueEspecial("Tesouro Dracônico", TipoPokemon.NORMAL, 120, 10));
        }
        @Override public String getDescricaoHabilidade() {
            return "Blaze: quando HP < 30%, dano de ataques de Fogo aumenta 50%.";
        }
        @Override public void aplicarHabilidadePassiva() {
            // Blaze é aplicada no cálculo de dano — sem efeito por turno
        }
        /** @return true se Blaze está ativa */
        public boolean blazeAtivo() {
            return getHpAtual() < getHpMax() * 0.30;
        }
    }

    /**
     * Blastoise — Tipo Água. Habilidade: Torrent (boost de dano com HP baixo).
     */
    public static class Blastoise extends Pokemon {
        public Blastoise() {
            super("Blastoise", TipoPokemon.AGUA, 268, 83, 100, 78);
            adicionarAtaque(new AtaqueEspecial("Hidro Bomba",   TipoPokemon.AGUA,   110, 5));
            adicionarAtaque(new AtaqueEspecial("Surf",          TipoPokemon.AGUA,    90, 15));
            adicionarAtaque(new AtaqueFisico  ("Rápido",        TipoPokemon.NORMAL,  40, 30));
            adicionarAtaque(new AtaqueEspecial("Blizzard",      TipoPokemon.AGUA,   110, 5));
        }
        @Override public String getDescricaoHabilidade() {
            return "Torrent: quando HP < 30%, dano de ataques de Água aumenta 50%.";
        }
        @Override public void aplicarHabilidadePassiva() {}
        public boolean torrentAtivo() { return getHpAtual() < getHpMax() * 0.30; }
    }

    /**
     * Venusaur — Tipo Planta. Habilidade: Overgrow + cura 5% HP por turno.
     */
    public static class Venusaur extends Pokemon {
        public Venusaur() {
            super("Venusaur", TipoPokemon.PLANTA, 270, 82, 83, 80);
            adicionarAtaque(new AtaqueEspecial("Pétala Dança",  TipoPokemon.PLANTA, 120, 10));
            adicionarAtaque(new AtaqueEspecial("Rayo Solar",    TipoPokemon.PLANTA, 110, 10));
            adicionarAtaque(new AtaqueFisico  ("Corte",         TipoPokemon.NORMAL,  70, 20));
            adicionarAtaque(new AtaqueEspecial("Tóxico Rayo",   TipoPokemon.PLANTA,  75, 15));
        }
        @Override public String getDescricaoHabilidade() {
            return "Overgrow: regenera 5% do HP máximo no início de cada turno.";
        }
        @Override public void aplicarHabilidadePassiva() {
            int cura = (int)(getHpMax() * 0.05);
            if (estaConsciente()) curar(cura);
        }
    }

    // ════════════════════════════════════════════════════════════
    //  TIME AZUL — Pikachu, Machamp, Alakazam
    // ════════════════════════════════════════════════════════════

    /**
     * Pikachu — Tipo Elétrico. Habilidade: Static (paralisa o inimigo passivamente).
     */
    public static class Pikachu extends Pokemon {
        public Pikachu() {
            super("Pikachu", TipoPokemon.ELETRICO, 211, 90, 55, 110);
            adicionarAtaque(new AtaqueEspecial("Trovão",        TipoPokemon.ELETRICO, 110, 10));
            adicionarAtaque(new AtaqueEspecial("Choque do Trovão", TipoPokemon.ELETRICO, 65, 20));
            adicionarAtaque(new AtaqueFisico  ("Investida",     TipoPokemon.NORMAL,   40, 35));
            adicionarAtaque(new AtaqueEspecial("Bola Elétrica", TipoPokemon.ELETRICO,  85, 15));
        }
        @Override public String getDescricaoHabilidade() {
            return "Static: 20% de chance de paralisar o oponente ao ser atacado.";
        }
        @Override public void aplicarHabilidadePassiva() {}
        /** Verifica se Static ativa neste turno. @return true se paralisou */
        public boolean verificarStatic() { return Math.random() < 0.20; }
    }

    /**
     * Machamp — Tipo Lutador. Habilidade: Guts (boost de ataque quando paralisado/envenenado).
     */
    public static class Machamp extends Pokemon {
        public Machamp() {
            super("Machamp", TipoPokemon.LUTADOR, 284, 130, 80, 55);
            adicionarAtaque(new AtaqueFisico("Soco de Dinamite", TipoPokemon.LUTADOR, 100, 5));
            adicionarAtaque(new AtaqueFisico("Golpe Baixo",      TipoPokemon.LUTADOR,  75, 20));
            adicionarAtaque(new AtaqueFisico("Nocaute",          TipoPokemon.LUTADOR, 120, 5));
            adicionarAtaque(new AtaqueFisico("Retaliação",       TipoPokemon.NORMAL,   70, 10));
        }
        @Override public String getDescricaoHabilidade() {
            return "Guts: no 3º turno consecutivo de batalha, ataque aumenta 30%.";
        }
        @Override public void aplicarHabilidadePassiva() {}
    }

    /**
     * Alakazam — Tipo Psíquico. Habilidade: Inner Focus, recupera 8% HP ao início do turno.
     */
    public static class Alakazam extends Pokemon {
        public Alakazam() {
            super("Alakazam", TipoPokemon.PSIQUICO, 218, 110, 45, 120);
            adicionarAtaque(new AtaqueEspecial("Psíquico",      TipoPokemon.PSIQUICO, 90, 10));
            adicionarAtaque(new AtaqueEspecial("Bola de Sombra",TipoPokemon.PSIQUICO, 80, 15));
            adicionarAtaque(new AtaqueEspecial("Foco de Energia",TipoPokemon.PSIQUICO,100, 5));
            adicionarAtaque(new AtaqueFisico  ("Corte Psíquico",TipoPokemon.PSIQUICO,  70, 20));
        }
        @Override public String getDescricaoHabilidade() {
            return "Inner Focus: recupera 8% do HP máximo no início de cada turno.";
        }
        @Override public void aplicarHabilidadePassiva() {
            if (estaConsciente()) curar((int)(getHpMax() * 0.08));
        }
    }

    // ════════════════════════════════════════════════════════════
    //  TIME VERDE — Gengar, Golem, Gyarados
    // ════════════════════════════════════════════════════════════

    /**
     * Gengar — Tipo Psíquico. Habilidade: Levitate (imune a ataques de Pedra).
     */
    public static class Gengar extends Pokemon {
        public Gengar() {
            super("Gengar", TipoPokemon.PSIQUICO, 240, 110, 55, 110);
            adicionarAtaque(new AtaqueEspecial("Bola Sombria",  TipoPokemon.PSIQUICO, 80, 15));
            adicionarAtaque(new AtaqueEspecial("Raio de Gelo",  TipoPokemon.AGUA,     90, 10));
            adicionarAtaque(new AtaqueEspecial("Trovão",        TipoPokemon.ELETRICO, 110, 10));
            adicionarAtaque(new AtaqueEspecial("Maldição Sombria", TipoPokemon.PSIQUICO, 100, 5));
        }
        @Override public String getDescricaoHabilidade() {
            return "Levitate: imune a ataques do tipo Pedra (dano reduzido a zero).";
        }
        @Override public void aplicarHabilidadePassiva() {}
        public boolean levitateAtivo(TipoPokemon tipoAtaque) {
            return tipoAtaque == TipoPokemon.PEDRA;
        }
    }

    /**
     * Golem — Tipo Pedra. Habilidade: Rock Head (reflete 10% do dano recebido).
     */
    public static class Golem extends Pokemon {
        public Golem() {
            super("Golem", TipoPokemon.PEDRA, 290, 120, 130, 45);
            adicionarAtaque(new AtaqueFisico("Terremoto",       TipoPokemon.PEDRA,   100, 10));
            adicionarAtaque(new AtaqueFisico("Pedrada",         TipoPokemon.PEDRA,    75, 15));
            adicionarAtaque(new AtaqueFisico("Explosão",        TipoPokemon.NORMAL,  250, 5));
            adicionarAtaque(new AtaqueFisico("Triturar",        TipoPokemon.NORMAL,   80, 15));
        }
        @Override public String getDescricaoHabilidade() {
            return "Rock Head: devolve 10% do dano recebido ao atacante.";
        }
        @Override public void aplicarHabilidadePassiva() {}
    }

    /**
     * Gyarados — Tipo Água. Habilidade: Intimidate (reduz 10% do ataque do oponente no 1º turno).
     */
    public static class Gyarados extends Pokemon {
        private boolean intimidateAplicado = false;

        public Gyarados() {
            super("Gyarados", TipoPokemon.AGUA, 268, 125, 79, 81);
            adicionarAtaque(new AtaqueFisico  ("Cachoeira",     TipoPokemon.AGUA,    100, 15));
            adicionarAtaque(new AtaqueEspecial("Hidro Bomba",   TipoPokemon.AGUA,    110, 5));
            adicionarAtaque(new AtaqueFisico  ("Morder",        TipoPokemon.NORMAL,   60, 25));
            adicionarAtaque(new AtaqueEspecial("Fúria do Dragão",TipoPokemon.NORMAL, 120, 5));
        }
        @Override public String getDescricaoHabilidade() {
            return "Intimidate: ao entrar em batalha, reduz 10% do ATK do oponente.";
        }
        @Override public void aplicarHabilidadePassiva() {}
        /** @return true se Intimidate ainda não foi aplicado */
        public boolean aplicarIntimidate() {
            if (!intimidateAplicado) { intimidateAplicado = true; return true; }
            return false;
        }
        /** Reseta Intimidate para nova batalha. */
        public void resetIntimidate() { intimidateAplicado = false; }
    }
}
