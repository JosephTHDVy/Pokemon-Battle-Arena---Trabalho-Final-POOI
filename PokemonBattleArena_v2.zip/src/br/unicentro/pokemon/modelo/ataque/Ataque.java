package br.unicentro.pokemon.modelo.ataque;

import br.unicentro.pokemon.modelo.TipoPokemon;

/**
 * Representa um ataque genérico que um Pokémon pode utilizar.
 * Subclasses definem o comportamento concreto do cálculo de dano.
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public abstract class Ataque {

    private final String nome;
    private final TipoPokemon tipo;
    private final int poder;
    private final int pp;
    private int ppAtual;

    /**
     * Constrói um ataque com seus atributos base.
     *
     * @param nome  nome do ataque
     * @param tipo  tipo elemental do ataque
     * @param poder potência base do ataque
     * @param pp    pontos de poder (usos disponíveis)
     */
    public Ataque(String nome, TipoPokemon tipo, int poder, int pp) {
        this.nome    = nome;
        this.tipo    = tipo;
        this.poder   = poder;
        this.pp      = pp;
        this.ppAtual = pp;
    }

    /**
     * Calcula o dano causado por este ataque, considerando
     * ataque do atacante, defesa do defensor e efetividade de tipo.
     *
     * @param ataqueAtacante stat de ataque do Pokémon que usa o golpe
     * @param defesaDefensor stat de defesa do Pokémon que recebe
     * @param tipoDefensor   tipo elemental do Pokémon defensor
     * @return dano inteiro calculado (mínimo 1)
     */
    public abstract int calcularDano(int ataqueAtacante, int defesaDefensor, TipoPokemon tipoDefensor);

    /**
     * Consome um PP deste ataque.
     *
     * @return {@code true} se o ataque pôde ser usado; {@code false} se sem PP
     */
    public boolean usar() {
        if (ppAtual <= 0) return false;
        ppAtual--;
        return true;
    }

    /** @return nome do ataque */
    public String getNome()   { return nome; }

    /** @return tipo elemental */
    public TipoPokemon getTipo() { return tipo; }

    /** @return potência base */
    public int getPoder()     { return poder; }

    /** @return PP máximo */
    public int getPp()        { return pp; }

    /** @return PP restante */
    public int getPpAtual()   { return ppAtual; }

    /**
     * Restaura todos os PP deste ataque.
     */
    public void restaurarPp() { ppAtual = pp; }

    @Override
    public String toString() {
        return String.format("%-16s  Tipo: %-9s  Poder: %3d  PP: %d/%d",
                nome, tipo.getNome(), poder, ppAtual, pp);
    }
}
