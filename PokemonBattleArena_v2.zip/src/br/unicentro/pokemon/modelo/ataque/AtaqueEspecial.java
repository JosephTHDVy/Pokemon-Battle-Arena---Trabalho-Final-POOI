package br.unicentro.pokemon.modelo.ataque;

import br.unicentro.pokemon.modelo.TipoPokemon;

/**
 * Ataque especial: ignora parte da defesa do oponente (penetração 30%).
 * Representa golpes mágicos/energéticos.
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public class AtaqueEspecial extends Ataque {

    private static final double PENETRACAO_DEFESA = 0.70; // usa só 70% da defesa inimiga

    /**
     * Cria um ataque especial.
     *
     * @param nome  nome do ataque
     * @param tipo  tipo elemental
     * @param poder potência base
     * @param pp    pontos de poder
     */
    public AtaqueEspecial(String nome, TipoPokemon tipo, int poder, int pp) {
        super(nome, tipo, poder, pp);
    }

    /**
     * {@inheritDoc}
     * Aplica penetração de defesa: {@code defEfetiva = defesa * 0.70}.
     *
     * @param ataqueAtacante stat de ataque especial do atacante
     * @param defesaDefensor stat de defesa especial do defensor
     * @param tipoDefensor   tipo do defensor para efetividade
     * @return dano causado
     */
    @Override
    public int calcularDano(int ataqueAtacante, int defesaDefensor, TipoPokemon tipoDefensor) {
        double mult       = getTipo().multiplicador(tipoDefensor);
        double rand       = 0.85 + Math.random() * 0.15;
        double defEfetiva = defesaDefensor * PENETRACAO_DEFESA;
        double dano       = (getPoder() * (double) ataqueAtacante / defEfetiva) * mult * rand;
        return Math.max(1, (int) dano);
    }

    @Override
    public String toString() {
        return super.toString() + "  [Especial]";
    }
}
