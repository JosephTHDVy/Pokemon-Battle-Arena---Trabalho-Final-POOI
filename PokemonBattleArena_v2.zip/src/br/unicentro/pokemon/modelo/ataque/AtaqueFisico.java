package br.unicentro.pokemon.modelo.ataque;

import br.unicentro.pokemon.modelo.TipoPokemon;

/**
 * Ataque físico: usa o stat de Ataque do atacante e Defesa do defensor.
 * Dano = (poder * ataque / defesa * multiplicadorTipo) com variação aleatória.
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public class AtaqueFisico extends Ataque {

    /**
     * Cria um ataque físico.
     *
     * @param nome  nome do ataque
     * @param tipo  tipo elemental
     * @param poder potência base
     * @param pp    pontos de poder
     */
    public AtaqueFisico(String nome, TipoPokemon tipo, int poder, int pp) {
        super(nome, tipo, poder, pp);
    }

    /**
     * {@inheritDoc}
     * Fórmula simplificada: {@code max(1, (poder * atk / def * mult * rand))}
     *
     * @param ataqueAtacante stat de ataque do atacante
     * @param defesaDefensor stat de defesa do defensor
     * @param tipoDefensor   tipo do defensor para calcular efetividade
     * @return dano causado
     */
    @Override
    public int calcularDano(int ataqueAtacante, int defesaDefensor, TipoPokemon tipoDefensor) {
        double mult  = getTipo().multiplicador(tipoDefensor);
        double rand  = 0.85 + Math.random() * 0.15; // 85%–100%
        double dano  = (getPoder() * (double) ataqueAtacante / defesaDefensor) * mult * rand;
        return Math.max(1, (int) dano);
    }
}
