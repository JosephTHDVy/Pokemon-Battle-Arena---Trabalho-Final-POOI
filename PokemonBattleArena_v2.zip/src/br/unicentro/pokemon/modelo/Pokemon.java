package br.unicentro.pokemon.modelo;

import br.unicentro.pokemon.excecao.AtaqueInvalidoException;
import br.unicentro.pokemon.excecao.PokemonSemForcaException;
import br.unicentro.pokemon.modelo.ataque.Ataque;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Classe base abstrata para todos os Pokémon do jogo.
 * Define atributos, HP, ataques e o contrato da habilidade passiva.
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public abstract class Pokemon implements Combatente {

    private final String     nome;
    private final TipoPokemon tipo;
    private final int        hpMax;
    private int              hpAtual;
    private final int        ataque;
    private final int        defesa;
    private final int        velocidade;
    private final List<Ataque> ataques;

    /**
     * Constrói um Pokémon com seus atributos base.
     *
     * @param nome       nome do Pokémon
     * @param tipo       tipo elemental
     * @param hp         pontos de vida máximos
     * @param ataque     stat de ataque
     * @param defesa     stat de defesa
     * @param velocidade stat de velocidade (determina quem age primeiro)
     */
    public Pokemon(String nome, TipoPokemon tipo, int hp,
                   int ataque, int defesa, int velocidade) {
        this.nome       = nome;
        this.tipo       = tipo;
        this.hpMax      = hp;
        this.hpAtual    = hp;
        this.ataque     = ataque;
        this.defesa     = defesa;
        this.velocidade = velocidade;
        this.ataques    = new ArrayList<>();
    }

    /**
     * Retorna a descrição da habilidade passiva exclusiva deste Pokémon.
     * Cada subclasse define sua própria habilidade.
     *
     * @return descrição textual da habilidade passiva
     */
    public abstract String getDescricaoHabilidade();

    /**
     * Aplica o efeito da habilidade passiva ao início de cada turno.
     * Subclasses implementam a lógica (ex.: cura, boost de ataque).
     */
    public abstract void aplicarHabilidadePassiva();

    // ─── Combatente ────────────────────────────────────────────────────────────

    /**
     * {@inheritDoc}
     *
     * @param indiceAtaque índice 0-based do ataque escolhido
     * @param alvo         Pokémon que receberá o dano
     * @return dano efetivamente causado
     * @exception AtaqueInvalidoException  se o índice estiver fora dos ataques disponíveis
     * @exception PokemonSemForcaException se este Pokémon estiver desmaiado
     */
    @Override
    public int atacar(int indiceAtaque, Pokemon alvo)
            throws AtaqueInvalidoException, PokemonSemForcaException {

        if (!estaConsciente()) {
            throw new PokemonSemForcaException(nome);
        }
        if (indiceAtaque < 0 || indiceAtaque >= ataques.size()) {
            throw new AtaqueInvalidoException(indiceAtaque + 1);
        }

        Ataque escolhido = ataques.get(indiceAtaque);
        if (!escolhido.usar()) {
            // sem PP — usa Luta como fallback
            int danoFallback = Math.max(1, ataque / 10);
            alvo.receberDano(danoFallback);
            return danoFallback;
        }

        int dano = escolhido.calcularDano(ataque, alvo.getDefesa(), alvo.getTipo());
        alvo.receberDano(dano);
        return dano;
    }

    /**
     * Aplica dano direto ao HP deste Pokémon (mínimo 0).
     *
     * @param dano quantidade de dano a subtrair do HP
     */
    public void receberDano(int dano) {
        hpAtual = Math.max(0, hpAtual - dano);
    }

    /**
     * Restaura HP deste Pokémon em {@code quantidade} pontos, até o máximo.
     *
     * @param quantidade HP a restaurar
     */
    public void curar(int quantidade) {
        hpAtual = Math.min(hpMax, hpAtual + quantidade);
    }

    /** @return {@code true} se HP > 0 */
    @Override
    public boolean estaConsciente() { return hpAtual > 0; }

    /**
     * Restaura HP ao máximo e PP de todos os ataques.
     * Usado ao iniciar nova batalha.
     */
    public void restaurarCompleto() {
        hpAtual = hpMax;
        ataques.forEach(Ataque::restaurarPp);
    }

    // ─── Ataques ───────────────────────────────────────────────────────────────

    /**
     * Adiciona um ataque ao conjunto deste Pokémon (máx. 4).
     *
     * @param atk ataque a adicionar
     */
    public void adicionarAtaque(Ataque atk) {
        if (ataques.size() < 4) ataques.add(atk);
    }

    /**
     * Retorna lista imutável de ataques deste Pokémon.
     *
     * @return lista de ataques
     */
    public List<Ataque> getAtaques() {
        return Collections.unmodifiableList(ataques);
    }

    // ─── Getters ───────────────────────────────────────────────────────────────

    /** @return nome do Pokémon */
    @Override
    public String getNome()    { return nome; }

    /** @return tipo elemental */
    public TipoPokemon getTipo() { return tipo; }

    /** @return HP máximo */
    public int getHpMax()      { return hpMax; }

    /** @return HP atual */
    public int getHpAtual()    { return hpAtual; }

    /** @return stat de ataque */
    public int getAtaque()     { return ataque; }

    /** @return stat de defesa */
    public int getDefesa()     { return defesa; }

    /** @return stat de velocidade */
    public int getVelocidade() { return velocidade; }

    @Override
    public String toString() {
        return String.format("%s [%s] HP:%d/%d ATK:%d DEF:%d VEL:%d",
                nome, tipo.getNome(), hpAtual, hpMax, ataque, defesa, velocidade);
    }
}
