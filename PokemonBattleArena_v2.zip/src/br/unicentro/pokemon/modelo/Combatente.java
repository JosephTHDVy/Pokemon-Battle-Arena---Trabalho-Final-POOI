package br.unicentro.pokemon.modelo;

import br.unicentro.pokemon.excecao.AtaqueInvalidoException;
import br.unicentro.pokemon.excecao.PokemonSemForcaException;

/**
 * Define o contrato de qualquer entidade que possa participar de um combate.
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public interface Combatente {

    /**
     * Executa um ataque pelo índice (0-based) contra um alvo.
     *
     * @param indiceAtaque índice do ataque escolhido
     * @param alvo         Pokémon que receberá o dano
     * @return dano causado ao alvo
     * @exception AtaqueInvalidoException   se o índice não corresponde a um ataque válido
     * @exception PokemonSemForcaException  se este Pokémon está desmaiado
     */
    int atacar(int indiceAtaque, Pokemon alvo)
            throws AtaqueInvalidoException, PokemonSemForcaException;

    /**
     * Verifica se o combatente ainda pode lutar.
     *
     * @return {@code true} se o HP for maior que zero
     */
    boolean estaConsciente();

    /**
     * Retorna o nome de exibição do combatente.
     *
     * @return nome
     */
    String getNome();
}
