package br.unicentro.pokemon.modelo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Representa um time de até três Pokémon.
 * Usa agregação: os Pokémon existem independentemente do time.
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public class Time {

    private final String nome;
    private final List<Pokemon> membros;

    /**
     * Cria um time com nome identificador.
     *
     * @param nome nome do time (ex.: "Time Vermelho")
     */
    public Time(String nome) {
        this.nome    = nome;
        this.membros = new ArrayList<>();
    }

    /**
     * Adiciona um Pokémon ao time (máx. 3).
     *
     * @param p Pokémon a adicionar
     */
    public void adicionarPokemon(Pokemon p) {
        if (membros.size() < 3) membros.add(p);
    }

    /** @return nome do time */
    public String getNome() { return nome; }

    /**
     * Retorna lista imutável dos membros do time.
     *
     * @return membros
     */
    public List<Pokemon> getMembros() {
        return Collections.unmodifiableList(membros);
    }

    /**
     * Verifica se ao menos um Pokémon do time está consciente.
     *
     * @return {@code true} se o time ainda pode batalhar
     */
    public boolean temPokemonVivo() {
        return membros.stream().anyMatch(Pokemon::estaConsciente);
    }

    /**
     * Restaura todos os Pokémon do time ao estado inicial.
     */
    public void restaurarTime() {
        membros.forEach(Pokemon::restaurarCompleto);
    }

    @Override
    public String toString() { return nome; }
}
