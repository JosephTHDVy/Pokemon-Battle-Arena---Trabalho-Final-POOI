package br.unicentro.pokemon.modelo;

/**
 * Representa os tipos elementais de um Pokémon.
 * Contém a lógica de efetividade entre tipos.
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public enum TipoPokemon {
    FOGO, AGUA, PLANTA, ELETRICO, NORMAL, PSIQUICO, LUTADOR, PEDRA;

    /**
     * Calcula o multiplicador de dano deste tipo atacando {@code defensor}.
     *
     * @param defensor tipo do Pokémon que recebe o ataque
     * @return 2.0 (super eficaz), 0.5 (não muito eficaz) ou 1.0 (normal)
     */
    public double multiplicador(TipoPokemon defensor) {
        return switch (this) {
            case FOGO     -> switch (defensor) {
                case PLANTA -> 2.0;
                case AGUA, PEDRA -> 0.5;
                default -> 1.0;
            };
            case AGUA     -> switch (defensor) {
                case FOGO, PEDRA -> 2.0;
                case PLANTA, ELETRICO -> 0.5;
                default -> 1.0;
            };
            case PLANTA   -> switch (defensor) {
                case AGUA, PEDRA -> 2.0;
                case FOGO, ELETRICO -> 0.5;
                default -> 1.0;
            };
            case ELETRICO -> switch (defensor) {
                case AGUA -> 2.0;
                case PLANTA, PEDRA -> 0.5;
                default -> 1.0;
            };
            case PSIQUICO -> switch (defensor) {
                case LUTADOR -> 2.0;
                case PEDRA -> 0.5;
                default -> 1.0;
            };
            case LUTADOR  -> switch (defensor) {
                case NORMAL, PEDRA -> 2.0;
                case PSIQUICO -> 0.5;
                default -> 1.0;
            };
            case PEDRA    -> switch (defensor) {
                case FOGO -> 2.0;
                case AGUA, PLANTA -> 0.5;
                default -> 1.0;
            };
            default -> 1.0;
        };
    }

    /**
     * Retorna o nome do tipo formatado para exibição.
     *
     * @return nome em português capitalizado
     */
    public String getNome() {
        return switch (this) {
            case FOGO     -> "Fogo";
            case AGUA     -> "Água";
            case PLANTA   -> "Planta";
            case ELETRICO -> "Elétrico";
            case NORMAL   -> "Normal";
            case PSIQUICO -> "Psíquico";
            case LUTADOR  -> "Lutador";
            case PEDRA    -> "Pedra";
        };
    }
}
