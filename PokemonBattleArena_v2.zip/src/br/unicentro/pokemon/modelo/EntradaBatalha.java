package br.unicentro.pokemon.modelo;

/**
 * Representa uma entrada no ranking de batalhas,
 * composta por composição (parte do sistema de ranking).
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public class EntradaBatalha implements Comparable<EntradaBatalha> {

    private final String nomeJogador;
    private final int    vitorias;
    private final int    derrotas;
    private final String pokemon;

    /**
     * Cria uma entrada de ranking.
     *
     * @param nomeJogador nome do jogador
     * @param vitorias    número de vitórias
     * @param derrotas    número de derrotas
     * @param pokemon     Pokémon favorito usado
     */
    public EntradaBatalha(String nomeJogador, int vitorias, int derrotas, String pokemon) {
        this.nomeJogador = nomeJogador;
        this.vitorias    = vitorias;
        this.derrotas    = derrotas;
        this.pokemon     = pokemon;
    }

    /** @return nome do jogador */
    public String getNomeJogador() { return nomeJogador; }

    /** @return vitórias acumuladas */
    public int getVitorias()       { return vitorias; }

    /** @return derrotas acumuladas */
    public int getDerrotas()       { return derrotas; }

    /** @return Pokémon favorito */
    public String getPokemon()     { return pokemon; }

    @Override
    public int compareTo(EntradaBatalha outro) {
        return Integer.compare(outro.vitorias, this.vitorias); // decrescente
    }

    /**
     * Converte para linha CSV para persistência em arquivo.
     *
     * @return linha no formato {@code nome;vitorias;derrotas;pokemon}
     */
    public String paraCsv() {
        return nomeJogador + ";" + vitorias + ";" + derrotas + ";" + pokemon;
    }

    /**
     * Cria uma EntradaBatalha a partir de uma linha CSV.
     *
     * @param linha linha no formato {@code nome;vitorias;derrotas;pokemon}
     * @return instância criada
     */
    public static EntradaBatalha deCsv(String linha) {
        String[] p = linha.split(";");
        return new EntradaBatalha(p[0], Integer.parseInt(p[1]),
                                  Integer.parseInt(p[2]), p[3]);
    }
}
