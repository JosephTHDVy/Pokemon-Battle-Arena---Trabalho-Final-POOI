package br.unicentro.pokemon.ui;

import br.unicentro.pokemon.modelo.EntradaBatalha;
import br.unicentro.pokemon.modelo.Pokemon;
import br.unicentro.pokemon.modelo.Time;
import br.unicentro.pokemon.modelo.ataque.Ataque;

import java.util.List;

/**
 * Responsável por toda a interface textual do jogo.
 * Centraliza impressão, menus, barras de HP e ANSI colors.
 * A lógica do jogo não depende diretamente de System.out,
 * apenas desta classe — separação UI / lógica.
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public final class Tela {

    // ─── Cores ANSI ────────────────────────────────────────────────────────────
    public static final String RESET  = "\u001B[0m";
    public static final String NEGRITO= "\u001B[1m";
    public static final String VERM   = "\u001B[31m";
    public static final String VERDE  = "\u001B[32m";
    public static final String AMAREL = "\u001B[33m";
    public static final String AZUL   = "\u001B[34m";
    public static final String MAGENTA= "\u001B[35m";
    public static final String CIANO  = "\u001B[36m";
    public static final String BRANCO = "\u001B[37m";
    public static final String FUNDO_CINZA = "\u001B[100m";

    private Tela() {}

    // ─── Utilitários ───────────────────────────────────────────────────────────

    /**
     * Imprime uma mensagem de log simples.
     *
     * @param msg mensagem a exibir
     */
    public static void log(String msg) { System.out.println(msg); }

    /** Imprime linha separadora decorativa. */
    public static void separador() {
        System.out.println(CIANO + "━".repeat(60) + RESET);
    }

    /** Limpa a tela (funciona em terminais ANSI). */
    public static void limpar() { System.out.print("\033[H\033[2J"); System.out.flush(); }

    /**
     * Exibe título grande do jogo.
     */
    public static void titulo() {
        limpar();
        System.out.println();
        System.out.println(AMAREL + NEGRITO +
            "  ██████╗  ██████╗ ██╗  ██╗███████╗███╗   ███╗ ██████╗ ███╗   ██╗" + RESET);
        System.out.println(AMAREL + NEGRITO +
            "  ██╔══██╗██╔═══██╗██║ ██╔╝██╔════╝████╗ ████║██╔═══██╗████╗  ██║" + RESET);
        System.out.println(AMAREL + NEGRITO +
            "  ██████╔╝██║   ██║█████╔╝ █████╗  ██╔████╔██║██║   ██║██╔██╗ ██║" + RESET);
        System.out.println(AMAREL + NEGRITO +
            "  ██╔═══╝ ██║   ██║██╔═██╗ ██╔══╝  ██║╚██╔╝██║██║   ██║██║╚██╗██║" + RESET);
        System.out.println(AMAREL + NEGRITO +
            "  ██║     ╚██████╔╝██║  ██╗███████╗██║ ╚═╝ ██║╚██████╔╝██║ ╚████║" + RESET);
        System.out.println(AMAREL + NEGRITO +
            "  ╚═╝      ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═══╝" + RESET);
        System.out.println(CIANO + "           ✦  Battle Arena  ✦  Java Edition  ✦" + RESET);
        System.out.println();
    }

    // ─── Seleção de time ───────────────────────────────────────────────────────

    /**
     * Exibe os três times disponíveis para escolha.
     *
     * @param times lista de times disponíveis
     */
    public static void exibirTimes(List<Time> times) {
        separador();
        System.out.println(NEGRITO + "  Escolha seu TIME:" + RESET);
        separador();
        for (int i = 0; i < times.size(); i++) {
            Time t = times.get(i);
            String cor = corTime(i);
            System.out.printf("%s  [%d] %s%s%n", cor, i + 1, t.getNome(), RESET);
            for (Pokemon p : t.getMembros()) {
                System.out.printf("       • %-12s  Tipo: %-9s  HP:%d  ATK:%d  VEL:%d%n",
                        p.getNome(), p.getTipo().getNome(),
                        p.getHpMax(), p.getAtaque(), p.getVelocidade());
                System.out.printf("         Passiva: %s%s%n",
                        MAGENTA, p.getDescricaoHabilidade() + RESET);
            }
            System.out.println();
        }
        separador();
    }

    /**
     * Exibe a tela de seleção do Pokémon inicial dentro do time.
     *
     * @param time time escolhido
     */
    public static void exibirSelecaoPokemon(Time time) {
        System.out.println();
        System.out.println(NEGRITO + "  Escolha seu POKÉMON inicial de " + time.getNome() + ":" + RESET);
        separador();
        List<Pokemon> membros = time.getMembros();
        for (int i = 0; i < membros.size(); i++) {
            Pokemon p = membros.get(i);
            System.out.printf("  [%d] %-12s  Tipo: %-9s  HP:%3d  ATK:%3d  DEF:%3d  VEL:%3d%n",
                    i + 1, p.getNome(), p.getTipo().getNome(),
                    p.getHpMax(), p.getAtaque(), p.getDefesa(), p.getVelocidade());
        }
        separador();
    }

    // ─── Arena de batalha ──────────────────────────────────────────────────────

    /**
     * Desenha a arena de batalha mostrando os dois Pokémon frente a frente.
     *
     * @param jogador Pokémon do jogador
     * @param inimigo Pokémon inimigo
     * @param turno   número do turno atual
     */
    public static void desenharArena(Pokemon jogador, Pokemon inimigo, int turno) {
        limpar();
        separador();
        System.out.printf(NEGRITO + "  ✦ BATALHA — Turno %-3d" + RESET + "%n", turno);
        separador();
        System.out.println();

        // Inimigo (lado direito)
        System.out.printf("  " + VERM + "%-14s" + RESET + "  Tipo: %-9s%n",
                inimigo.getNome(), inimigo.getTipo().getNome());
        System.out.print("  ");
        barraHp(inimigo);
        System.out.println();

        System.out.println("  " + CIANO +
                "           (vs)" + RESET);
        System.out.println();

        // Jogador (lado esquerdo)
        System.out.printf("  " + VERDE + "%-14s" + RESET + "  Tipo: %-9s%n",
                jogador.getNome(), jogador.getTipo().getNome());
        System.out.print("  ");
        barraHp(jogador);
        System.out.println();
        separador();
    }

    /**
     * Exibe o menu de ataques disponíveis para o jogador.
     *
     * @param pokemon Pokémon cujos ataques serão exibidos
     */
    public static void exibirMenuAtaque(Pokemon pokemon) {
        System.out.println(NEGRITO + "\n  O que " + pokemon.getNome() + " vai fazer?" + RESET);
        System.out.println();
        List<Ataque> ataques = pokemon.getAtaques();
        for (int i = 0; i < ataques.size(); i++) {
            Ataque a = ataques.get(i);
            String ppCor = a.getPpAtual() > 0 ? BRANCO : VERM;
            System.out.printf("  " + AMAREL + "[%d]" + RESET + " %-18s  " +
                            "Tipo:%-9s  Poder:%3d  PP:%s%d/%d%s%n",
                    i + 1, a.getNome(), a.getTipo().getNome(),
                    a.getPoder(), ppCor, a.getPpAtual(), a.getPp(), RESET);
        }
        System.out.println();
        System.out.println(CIANO + "  [0] Trocar Pokémon" + RESET);
        System.out.println(CIANO + "  [9] Fugir" + RESET);
        separador();
        System.out.print("  Escolha: ");
    }

    /**
     * Exibe lista de Pokémon disponíveis para troca.
     *
     * @param time time do jogador
     */
    public static void exibirTrocaPokemon(Time time) {
        System.out.println();
        System.out.println(NEGRITO + "  Escolha o Pokémon para enviar:" + RESET);
        separador();
        List<Pokemon> membros = time.getMembros();
        for (int i = 0; i < membros.size(); i++) {
            Pokemon p = membros.get(i);
            String status = p.estaConsciente()
                    ? VERDE + "  OK " + RESET
                    : VERM  + " DESMAIADO" + RESET;
            System.out.printf("  [%d] %-12s  HP: %3d/%-3d  %s%n",
                    i + 1, p.getNome(), p.getHpAtual(), p.getHpMax(), status);
        }
        separador();
        System.out.print("  Escolha: ");
    }

    // ─── Resultados ────────────────────────────────────────────────────────────

    /**
     * Exibe mensagem de vitória.
     *
     * @param nomePokemon nome do Pokémon vencedor
     */
    public static void vitoria(String nomePokemon) {
        separador();
        System.out.println(VERDE + NEGRITO +
                "  🏆  " + nomePokemon + " venceu a batalha!" + RESET);
        separador();
    }

    /**
     * Exibe mensagem de derrota.
     *
     * @param nomePokemon nome do Pokémon derrotado
     */
    public static void derrota(String nomePokemon) {
        separador();
        System.out.println(VERM + NEGRITO +
                "  💀  " + nomePokemon + " desmaiou!" + RESET);
        separador();
    }

    /**
     * Exibe o ranking completo de batalhas.
     *
     * @param ranking lista ordenada de entradas
     */
    public static void exibirRanking(List<EntradaBatalha> ranking) {
        limpar();
        separador();
        System.out.println(AMAREL + NEGRITO + "  🏅  RANKING DE BATALHAS" + RESET);
        separador();
        if (ranking.isEmpty()) {
            System.out.println("  Nenhuma batalha registrada ainda.");
        } else {
            System.out.printf("  %-4s %-16s %-8s %-8s %-14s%n",
                    "Pos.", "Jogador", "Vitórias", "Derrotas", "Pokémon Fav.");
            separador();
            for (int i = 0; i < ranking.size(); i++) {
                EntradaBatalha e = ranking.get(i);
                System.out.printf("  %-4d %-16s %-8d %-8d %-14s%n",
                        i + 1, e.getNomeJogador(),
                        e.getVitorias(), e.getDerrotas(), e.getPokemon());
            }
        }
        separador();
    }

    // ─── Internos ──────────────────────────────────────────────────────────────

    private static void barraHp(Pokemon p) {
        int total  = 20;
        int cheios = (int)((double) p.getHpAtual() / p.getHpMax() * total);
        cheios = Math.max(0, Math.min(total, cheios));

        String cor = cheios > 12 ? VERDE : cheios > 6 ? AMAREL : VERM;
        String barra = cor + "█".repeat(cheios) + RESET +
                       "░".repeat(total - cheios);

        System.out.printf("HP [%s] %3d/%-3d%n", barra, p.getHpAtual(), p.getHpMax());
    }

    private static String corTime(int idx) {
        return switch (idx) {
            case 0 -> VERM;
            case 1 -> AZUL;
            case 2 -> VERDE;
            default -> BRANCO;
        };
    }
}
