package br.unicentro.pokemon.dados;

import br.unicentro.pokemon.modelo.Time;
import br.unicentro.pokemon.modelo.pokemon.TodosPokemon.*;

/**
 * Fábrica responsável por instanciar os três times do jogo.
 * Centraliza a criação para facilitar manutenção e testes.
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public final class FabricaTime {

    private FabricaTime() {}

    /**
     * Cria o Time Vermelho: Charizard, Blastoise, Venusaur.
     *
     * @return Time Vermelho configurado
     */
    public static Time criarTimeVermelho() {
        Time t = new Time("Time Vermelho");
        t.adicionarPokemon(new Charizard());
        t.adicionarPokemon(new Blastoise());
        t.adicionarPokemon(new Venusaur());
        return t;
    }

    /**
     * Cria o Time Azul: Pikachu, Machamp, Alakazam.
     *
     * @return Time Azul configurado
     */
    public static Time criarTimeAzul() {
        Time t = new Time("Time Azul");
        t.adicionarPokemon(new Pikachu());
        t.adicionarPokemon(new Machamp());
        t.adicionarPokemon(new Alakazam());
        return t;
    }

    /**
     * Cria o Time Verde: Gengar, Golem, Gyarados.
     *
     * @return Time Verde configurado
     */
    public static Time criarTimeVerde() {
        Time t = new Time("Time Verde");
        t.adicionarPokemon(new Gengar());
        t.adicionarPokemon(new Golem());
        t.adicionarPokemon(new Gyarados());
        return t;
    }
}
