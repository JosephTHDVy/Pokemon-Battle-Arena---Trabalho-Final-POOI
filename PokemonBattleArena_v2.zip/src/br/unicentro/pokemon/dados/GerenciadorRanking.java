package br.unicentro.pokemon.dados;

import br.unicentro.pokemon.modelo.EntradaBatalha;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Gerencia a persistência do ranking de batalhas em arquivo CSV.
 * Responsável por carregar, salvar e atualizar entradas.
 *
 * @author Guizo
 * @version 1.0
 * @since 2026-06
 */
public class GerenciadorRanking {

    private static final String ARQUIVO_RANKING = "recursos/ranking.csv";
    private final List<EntradaBatalha> entradas;

    /**
     * Cria o gerenciador e carrega o ranking do disco.
     */
    public GerenciadorRanking() {
        this.entradas = new ArrayList<>();
        carregar();
    }

    /**
     * Carrega as entradas do arquivo CSV para memória.
     * Cria o arquivo se não existir.
     */
    private void carregar() {
        Path path = Path.of(ARQUIVO_RANKING);
        try {
            Files.createDirectories(path.getParent());
            if (!Files.exists(path)) {
                Files.createFile(path);
                return;
            }
            List<String> linhas = Files.readAllLines(path);
            for (String linha : linhas) {
                if (!linha.isBlank()) {
                    entradas.add(EntradaBatalha.deCsv(linha.trim()));
                }
            }
        } catch (IOException e) {
            System.err.println("[AVISO] Não foi possível carregar o ranking: " + e.getMessage());
        }
    }

    /**
     * Persiste o ranking atual no arquivo CSV.
     */
    public void salvar() {
        Path path = Path.of(ARQUIVO_RANKING);
        try (BufferedWriter bw = Files.newBufferedWriter(path)) {
            for (EntradaBatalha e : entradas) {
                bw.write(e.paraCsv());
                bw.newLine();
            }
        } catch (IOException e) {
            System.err.println("[AVISO] Não foi possível salvar o ranking: " + e.getMessage());
        }
    }

    /**
     * Registra ou atualiza o resultado de um jogador.
     * Se o jogador já existir (pelo nome), incrementa vitórias/derrotas.
     * Caso contrário, cria nova entrada.
     *
     * @param nomeJogador nome do jogador
     * @param vitoria     {@code true} se venceu
     * @param pokemon     Pokémon usado na batalha
     */
    public void registrar(String nomeJogador, boolean vitoria, String pokemon) {
        for (int i = 0; i < entradas.size(); i++) {
            if (entradas.get(i).getNomeJogador().equalsIgnoreCase(nomeJogador)) {
                EntradaBatalha antiga = entradas.get(i);
                entradas.set(i, new EntradaBatalha(
                        nomeJogador,
                        antiga.getVitorias() + (vitoria ? 1 : 0),
                        antiga.getDerrotas() + (vitoria ? 0 : 1),
                        pokemon
                ));
                salvar();
                return;
            }
        }
        entradas.add(new EntradaBatalha(nomeJogador,
                vitoria ? 1 : 0, vitoria ? 0 : 1, pokemon));
        salvar();
    }

    /**
     * Retorna lista ordenada (mais vitórias primeiro) do ranking.
     *
     * @return lista imutável e ordenada
     */
    public List<EntradaBatalha> getRankingOrdenado() {
        List<EntradaBatalha> copia = new ArrayList<>(entradas);
        Collections.sort(copia);
        return Collections.unmodifiableList(copia);
    }
}
