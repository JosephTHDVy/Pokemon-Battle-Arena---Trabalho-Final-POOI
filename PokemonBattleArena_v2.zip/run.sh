#!/bin/bash
# Pokémon Battle Arena — script de compilação e execução
# Uso: ./run.sh

echo "=== Compilando Pokémon Battle Arena ==="
mkdir -p out
find src -name "*.java" | xargs javac -d out
if [ $? -ne 0 ]; then
    echo "ERRO: falha na compilação."
    exit 1
fi
echo "Compilação OK. Iniciando jogo..."
echo ""
java -cp out br.unicentro.pokemon.Main
